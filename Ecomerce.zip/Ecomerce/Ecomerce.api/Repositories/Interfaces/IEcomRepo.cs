﻿using Ecomerce.api.Models;

namespace Ecomerce.api.Repositories.Interfaces
{
    public interface IEcomRepo
    {
        // User
        void Add(User user);
        User GetByName(string name);

        // Product
        List<Product> GetAll();
        void Add(Product product);
        Product GetById(int id);
        void Update(Product product);
        void Delete(Product product);

        //Category
        bool Exists(int categoryId);
        List<Category> GetAllCats();
        Category GetCatById(int id);
        void Add(Category category);
        void Update(Category category);
        void Delete(Category category);

        //Cart
        Task<List<Cart>> GetUserCart(int userId);
        Task<Cart> GetCartItem(int userId, int productId);
        Task Add(Cart cart);
        Task Update(Cart cart);
        Task Delete(Cart cart);

        //Order
        Task AddAsync(Order order);
        Task<List<Order>> GetUserOrdersAsync(int userId);
        Task<List<Cart>> GetUserCartAsync(int userId);
        Task ClearCartAsync(int userId);


    }
}
