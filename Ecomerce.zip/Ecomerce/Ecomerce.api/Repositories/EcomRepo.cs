﻿using Ecomerce.api.Data;
using Ecomerce.api.Models;
using Ecomerce.api.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Ecomerce.api.Repositories
{
    public class EcomRepo : IEcomRepo
    {
        private readonly AppDbContext _context;
        public EcomRepo(AppDbContext dbContext)
        {
            _context = dbContext;
        }

        public void Add(User user)
        {
            _context.Add(user);
            _context.SaveChanges();
        }

        public User GetByName(string name)
        {
            return _context.users.SingleOrDefault(u => u.Name == name);
        }


        //Products
        public List<Product> GetAll()
        {
            return _context.products
                           .Include(p => p.Category)
                           .ToList();
        }

        public void Add(Product product)
        {
            _context.products.Add(product);
            _context.SaveChanges();
        }

        public Product GetById(int id)
        {
            return _context.products.Find(id);
        }

        public void Update(Product product)
        {
            _context.products.Update(product);
            _context.SaveChanges();
        }

        public void Delete(Product product)
        {
            _context.products.Remove(product);
            _context.SaveChanges();
        }



        // Categories
        public List<Category> GetAllCats()
        {
            return _context.categories.ToList();
        }

        public Category GetCatById(int id)
        {
            return _context.categories.Find(id);
        }

        public bool Exists(int categoryId)
        {
            return _context.categories.Any(c => c.CategoryId == categoryId);
        }

        public void Add(Category category)
        {
            _context.categories.Add(category);
            _context.SaveChanges();
        }

        public void Update(Category category)
        {
            _context.categories.Update(category);
            _context.SaveChanges();
        }

        public void Delete(Category category)
        {
            _context.categories.Remove(category);
            _context.SaveChanges();
        }


        //Cart
        public async Task<List<Cart>> GetUserCart(int userId)
        {
            return await _context.carts
                .Include(c => c.Product)
                .Where(c => c.UserId == userId)
                .ToListAsync();
        }

        public async Task<Cart> GetCartItem(int userId, int productId)
        {
            return await _context.carts
                .FirstOrDefaultAsync(c => c.UserId == userId && c.ProductId == productId);
        }

        public async Task Add(Cart cart)
        {
            _context.carts.Add(cart);
            await _context.SaveChangesAsync();
        }

        public async Task Update(Cart cart)
        {
            _context.carts.Update(cart);
            await _context.SaveChangesAsync();
        }

        public async Task Delete(Cart cart)
        {
            _context.carts.Remove(cart);
            await _context.SaveChangesAsync();
        }


        //Order
        public async Task AddAsync(Order order)
        {
            _context.orders.Add(order);
            await _context.SaveChangesAsync();
        }

        public async Task<List<Order>> GetUserOrdersAsync(int userId)
        {
            return await _context.orders
                .Include(o => o.Product)
                .Where(o => o.UserId == userId)
                .ToListAsync();
        }

        public async Task<List<Cart>> GetUserCartAsync(int userId)
        {
            return await _context.carts
                .Include(c => c.Product)
                .Where(c => c.UserId == userId)
                .ToListAsync();
        }

        public async Task ClearCartAsync(int userId)
        {
            var cartItems = await _context.carts
                .Where(c => c.UserId == userId)
                .ToListAsync();

            _context.carts.RemoveRange(cartItems);
            await _context.SaveChangesAsync();
        }

    }
}
