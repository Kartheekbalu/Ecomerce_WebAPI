﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Ecomerce.api.Models
{
    public class Order
    {
        [Key]
        public int Id { get; set; }

        // FK → User
        [Required]
        public int UserId { get; set; }

        // FK → Product
        [Required]
        public int ProductId { get; set; }

        public int Quantity { get; set; }

        [Required]
        [MaxLength(50)]
        public string Status { get; set; }  // Pending, Confirmed, Shipped, Delivered

        // Navigation Properties
        [ForeignKey("UserId")]
        public User User { get; set; }

        [ForeignKey("ProductId")]
        public Product Product { get; set; }
    }
}
