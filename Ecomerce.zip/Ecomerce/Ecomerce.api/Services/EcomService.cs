﻿using AutoMapper;
using Ecomerce.api.Data.DTO;
using Ecomerce.api.Data.DTO.Cart;
using Ecomerce.api.Data.DTO.Category;
using Ecomerce.api.Data.DTO.Product;
using Ecomerce.api.Models;
using Ecomerce.api.Repositories.Interfaces;
using Ecomerce.api.Services.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Ecomerce.api.Services
{
    public class EcomService : IEcomService
    {
        private readonly IEcomRepo _repo;
        private readonly IMapper _mapper;
        private readonly IConfiguration _config;

        public EcomService(IEcomRepo ecomRepo, IMapper mapper, IConfiguration config)
        {
            _mapper = mapper;
            _repo = ecomRepo;
            _config = config;
        }

        public void AddUser(CreateUserDTO dto)
        {
            if (dto != null)
            {
                dto.Password= BCrypt.Net.BCrypt.HashPassword(dto.Password);
                var user = _mapper.Map<User>(dto);
                _repo.Add(user);
            }
        }

        public LoginResponseDto Login(LoginRequestDto model)
        {
            var user = _repo.GetByName(model.Name);

            if (user == null)
                throw new UnauthorizedAccessException("Invalid credentials");

            bool isValid = BCrypt.Net.BCrypt.Verify(model.Password, user.Password);

            if (!isValid)
                throw new UnauthorizedAccessException("Invalid credentials");

            var token = GenerateToken(user.Id,user.Email, user.Name);

            return new LoginResponseDto
            {
                Token = token,
                UserId = user.Id,
                Email = user.Email
            };
        }

        private string GenerateToken(int id,string email, string name)
        {
            string role = name == "Admin" ? "Admin" : "User";

            var claims = new[]
            {
            new Claim(ClaimTypes.NameIdentifier, id.ToString()),
            new Claim(ClaimTypes.Name, email),
            new Claim(ClaimTypes.Role, role)
        };

            var key = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(_config["Jwt:Key"])
            );

            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: _config["Jwt:Issuer"],
                audience: _config["Jwt:Audience"],
                claims: claims,
                expires: DateTime.Now.AddMinutes(
                    Convert.ToDouble(_config["Jwt:ExpireMinutes"])
                ),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        //Products
        public List<ProductDto> GetProducts()
        {
            var products = _repo.GetAll();
            return _mapper.Map<List<ProductDto>>(products);
        }

        public ProductDto GetProdById(int id)
        {
            var prod = _repo.GetById(id);
            if (prod == null)
                throw new Exception("Category not found");

            return _mapper.Map<ProductDto>(prod);
        }
        public void CreateProduct(ProductCreateDto dto)
        {
            if (!_repo.Exists(dto.CategoryId))
                throw new Exception("Invalid Category");

            var product = _mapper.Map<Product>(dto);
            _repo.Add(product);
        }

        public void UpdateProduct(ProductUpdateDto dto)
        {
            var product = _repo.GetById(dto.Id);

            if (product == null)
                throw new Exception("Product not found");

            if (!_repo.Exists(dto.CategoryId))
                throw new Exception("Invalid Category");

            _mapper.Map(dto, product);
            _repo.Update(product);
        }

        public void DeleteProduct(int id)
        {
            var product = _repo.GetById(id);

            if (product == null)
                throw new Exception("Product not found");

            _repo.Delete(product);
        }


        //Categories
        public List<CategoryDto> GetCategories()
        {
            var categories = _repo.GetAllCats();
            return _mapper.Map<List<CategoryDto>>(categories);
        }

        public CategoryDto GetCategoryById(int id)
        {
            var category = _repo.GetCatById(id);
            if (category == null)
                throw new Exception("Category not found");

            return _mapper.Map<CategoryDto>(category);
        }

        public void CreateCategory(CategoryCreateDto dto)
        {
            var category = _mapper.Map<Category>(dto);
            _repo.Add(category);
        }

        public void UpdateCategory(CategoryUpdateDto dto)
        {
            var category = _repo.GetCatById(dto.CategoryId);

            if (category == null)
                throw new Exception("Category not found");

            _mapper.Map(dto, category);
            _repo.Update(category);
        }

        public void DeleteCategory(int id)
        {
            var category = _repo.GetCatById(id);

            if (category == null)
                throw new Exception("Category not found");

            _repo.Delete(category);
        }



        //Cart
        public async Task<List<CartReadDto>> GetUserCart(int userId)
        {
            var cartItems = await _repo.GetUserCart(userId);
            return _mapper.Map<List<CartReadDto>>(cartItems);
        }

        public async Task AddToCart(int userId, AddToCartDto dto)
        {
            var existing = await _repo.GetCartItem(userId, dto.ProductId);

            if (existing != null)
            {
                existing.Quantity += dto.Quantity;
                await _repo.Update(existing);
                return;
            }

            var cart = _mapper.Map<Cart>(dto);
            cart.UserId = userId;

            await _repo.Add(cart);
        }

        public async Task UpdateQuantity(int userId, int productId, UpdateCartDto dto)
        {
            var cart = await _repo.GetCartItem(userId, productId);
            if (cart == null) throw new Exception("Cart item not found");

            cart.Quantity = dto.Quantity;
            await _repo.Update(cart);
        }

        public async Task RemoveFromCart(int userId, int productId)
        {
            var cart = await _repo.GetCartItem(userId, productId);
            if (cart == null) throw new Exception("Cart item not found");

            await _repo.Delete(cart);
        }



        //Order
        public async Task PlaceOrderAsync(int userId)
        {
            var cartItems = await _repo.GetUserCartAsync(userId);

            if (!cartItems.Any())
                throw new Exception("Cart is empty");

            foreach (var item in cartItems)
            {
                var order = new Order
                {
                    UserId = userId,
                    ProductId = item.ProductId,
                    Quantity = item.Quantity,
                    Status = "Placed"
                };

                await _repo.AddAsync(order);
            }

            await _repo.ClearCartAsync(userId);
        }

        public async Task<List<OrderResponseDto>> GetUserOrdersAsync(int userId)
        {
            var orders = await _repo.GetUserOrdersAsync(userId);
            return _mapper.Map<List<OrderResponseDto>>(orders);
        }



    }
}
