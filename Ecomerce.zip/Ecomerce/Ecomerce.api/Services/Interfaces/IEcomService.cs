﻿using Ecomerce.api.Data.DTO;
using Ecomerce.api.Data.DTO.Cart;
using Ecomerce.api.Data.DTO.Category;
using Ecomerce.api.Data.DTO.Product;

namespace Ecomerce.api.Services.Interfaces
{
    public interface IEcomService
    {
        // User
        public void AddUser(CreateUserDTO dto);
        LoginResponseDto Login(LoginRequestDto model);

        // Product
        List<ProductDto> GetProducts();
        ProductDto GetProdById(int id);
        void CreateProduct(ProductCreateDto dto);
        void UpdateProduct(ProductUpdateDto dto);
        void DeleteProduct(int id);

        //Categories
        List<CategoryDto> GetCategories();
        CategoryDto GetCategoryById(int id);
        void CreateCategory(CategoryCreateDto dto);
        void UpdateCategory(CategoryUpdateDto dto);
        void DeleteCategory(int id);


        //Cart
        Task<List<CartReadDto>> GetUserCart(int userId);
        Task AddToCart(int userId, AddToCartDto dto);
        Task UpdateQuantity(int userId, int productId, UpdateCartDto dto);
        Task RemoveFromCart(int userId, int productId);


        //Order
        Task PlaceOrderAsync(int userId);
        Task<List<OrderResponseDto>> GetUserOrdersAsync(int userId);


    }
}
