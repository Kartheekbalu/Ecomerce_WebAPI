﻿using AutoMapper;
using Ecomerce.api.Data.DTO;
using Ecomerce.api.Data.DTO.Cart;
using Ecomerce.api.Data.DTO.Category;
using Ecomerce.api.Data.DTO.Product;
using Ecomerce.api.Models;

namespace Ecomerce.api.Data
{
    public class MappingProfile:Profile
    {
        public MappingProfile()
        {
            //Mappings
            CreateMap<CreateUserDTO, User>();

            //Prod
            CreateMap<ProductCreateDto, Product>();

            CreateMap<Product, ProductDto>()
                .ForMember(dest => dest.CategoryName,
                           opt => opt.MapFrom(src => src.Category.Name));

            CreateMap<ProductUpdateDto, Product>();

            //cats
            CreateMap<Category, CategoryDto>();
            CreateMap<CategoryCreateDto, Category>();
            CreateMap<CategoryUpdateDto, Category>();


            //Cart
            CreateMap<Cart, CartReadDto>()
            .ForMember(dest => dest.CartId, opt => opt.MapFrom(src => src.Id))
            .ForMember(dest => dest.ProductName, opt => opt.MapFrom(src => src.Product.Name))
            .ForMember(dest => dest.Price, opt => opt.MapFrom(src => src.Product.Price));

            CreateMap<AddToCartDto, Cart>();

            //Order
            CreateMap<Order, OrderResponseDto>()
                .ForMember(dest => dest.ProductName,
                    opt => opt.MapFrom(src => src.Product.Name))
                .ForMember(dest => dest.Price,
                    opt => opt.MapFrom(src => src.Product.Price));



        }
    }
}
