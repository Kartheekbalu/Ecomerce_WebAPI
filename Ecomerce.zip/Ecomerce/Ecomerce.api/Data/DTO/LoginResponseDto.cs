﻿namespace Ecomerce.api.Data.DTO
{
    public class LoginResponseDto
    {
        public string Token { get; set; }
        public int UserId { get; set; }
        public string Email { get; set; }
    }
}
