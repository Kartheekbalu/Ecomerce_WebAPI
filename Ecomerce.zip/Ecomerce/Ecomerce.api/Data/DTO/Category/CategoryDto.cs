﻿namespace Ecomerce.api.Data.DTO.Category
{
    public class CategoryDto
    {
        public int CategoryId { get; set; }
        public string? Name { get; set; }
    }
}
