﻿namespace Ecomerce.api.Data.DTO.Category
{
    public class CategoryCreateDto
    {
        public string? Name { get; set; }
    }
}
