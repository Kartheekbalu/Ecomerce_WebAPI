﻿namespace Ecomerce.api.Data.DTO
{
    public class LoginRequestDto
    {
        public string Name { get; set; }
        public string Password { get; set; }
    }
}
