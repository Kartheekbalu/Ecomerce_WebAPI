﻿namespace Ecomerce.api.Data.DTO.Cart
{
    public class AddToCartDto
    {
        public int ProductId { get; set; }
        public int Quantity { get; set; }
    }
}

