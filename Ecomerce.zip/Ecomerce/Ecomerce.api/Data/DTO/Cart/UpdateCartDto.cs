﻿namespace Ecomerce.api.Data.DTO.Cart
{
    public class UpdateCartDto
    {
        public int Quantity { get; set; }
    }
}
