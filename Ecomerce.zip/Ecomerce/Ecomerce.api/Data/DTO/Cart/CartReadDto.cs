﻿namespace Ecomerce.api.Data.DTO.Cart
{
    public class CartReadDto
    {
        public int CartId { get; set; }
        public int ProductId { get; set; }

        public string ProductName { get; set; }
        public decimal Price { get; set; }

        public int Quantity { get; set; }

    }
}
