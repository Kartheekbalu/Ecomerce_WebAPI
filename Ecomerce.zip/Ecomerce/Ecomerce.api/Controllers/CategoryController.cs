﻿using Ecomerce.api.Data.DTO.Category;
using Ecomerce.api.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Ecomerce.api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles ="Admin")]
    public class CategoryController : ControllerBase
    {
        private readonly IEcomService _service;

        public CategoryController(IEcomService service)
        {
            _service = service;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            return Ok(_service.GetCategories());
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            return Ok(_service.GetCategoryById(id));
        }

        [HttpPost]
        public IActionResult Create(CategoryCreateDto dto)
        {
            _service.CreateCategory(dto);
            return Ok("Category created");
        }

        [HttpPut]
        public IActionResult Update(CategoryUpdateDto dto)
        {
            _service.UpdateCategory(dto);
            return Ok("Category updated");
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            _service.DeleteCategory(id);
            return Ok("Category deleted");
        }
    }
}
