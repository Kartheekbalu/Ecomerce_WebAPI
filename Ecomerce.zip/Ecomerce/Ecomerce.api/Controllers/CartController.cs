﻿using Ecomerce.api.Data.DTO.Cart;
using Ecomerce.api.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors.Infrastructure;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace Ecomerce.api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class CartController : ControllerBase
    {
        private readonly IEcomService _service;

        public CartController(IEcomService service)
        {
            _service = service;
        }

        private int GetUserId()
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier);

            if (userIdClaim == null)
                throw new Exception("UserId claim not found in token");

            return int.Parse(userIdClaim.Value);
        }


        // GET: api/cart
        [HttpGet]
        public async Task<IActionResult> GetCart()
        {
            var result = await _service.GetUserCart(GetUserId());
            return Ok(result);
        }

        // POST: api/cart
        [HttpPost]
        public async Task<IActionResult> AddToCart(AddToCartDto dto)
        {
            await _service.AddToCart(GetUserId(), dto);
            return Ok("Product added to cart");
        }

        // PUT: api/cart/2
        [HttpPut("{productId}")]
        public async Task<IActionResult> UpdateQuantity(int productId, UpdateCartDto dto)
        {
            await _service.UpdateQuantity(GetUserId(), productId, dto);
            return Ok("Cart updated");
        }

        // DELETE: api/cart/2
        [HttpDelete("{productId}")]
        public async Task<IActionResult> Delete(int productId)
        {
            await _service.RemoveFromCart(GetUserId(), productId);
            return Ok("Product removed from cart");
        }
    }
}
