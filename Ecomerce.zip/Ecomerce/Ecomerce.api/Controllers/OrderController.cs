﻿using Ecomerce.api.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace Ecomerce.api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class OrderController : ControllerBase
    {
        private readonly IEcomService _service;

        public OrderController(IEcomService service)
        {
            _service = service;
        }

        private int GetUserId()
        {
            return int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);
        }

        // POST: api/order
        [HttpPost]
        public async Task<IActionResult> PlaceOrder()
        {
            await _service.PlaceOrderAsync(GetUserId());
            return Ok(new { message = "Order placed successfully" });
        }

        // GET: api/order
        [HttpGet]
        public async Task<IActionResult> GetOrders()
        {
            var orders = await _service.GetUserOrdersAsync(GetUserId());
            return Ok(orders);
        }


    }
}
