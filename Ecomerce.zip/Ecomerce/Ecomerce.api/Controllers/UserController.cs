﻿using Ecomerce.api.Data.DTO;
using Ecomerce.api.Models;
using Ecomerce.api.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Ecomerce.api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : ControllerBase
    {
        private readonly IEcomService _service;

        public UserController(IEcomService service)
        {
            _service = service;
        }

        [HttpPost]
        [Route("signup")]
        public IActionResult SignUp([FromBody] CreateUserDTO user)
        {
            _service.AddUser(user);
            return Ok("User registered successfully");
        }

        

        [HttpPost("login")]
        public IActionResult Login([FromBody] LoginRequestDto model)
        {
            try
            {
                var result = _service.Login(model);
                return Ok(result);
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
        }


    }
}
