﻿using Ecomerce.api.Data.DTO.Product;
using Ecomerce.api.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Ecomerce.api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductController : ControllerBase
    {
        private readonly IEcomService _service;

        public ProductController(IEcomService service)
        {
            _service = service;
        }

        [HttpGet]
        public IActionResult Get()
        {
            return Ok(_service.GetProducts());
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            return Ok(_service.GetProdById(id));
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public IActionResult Create(ProductCreateDto dto)
        {
            _service.CreateProduct(dto);
            return Ok("Product created");
        }


        [Authorize(Roles = "Admin")]
        [HttpPut]
        public IActionResult Update(ProductUpdateDto dto)
        {
            _service.UpdateProduct(dto);
            return Ok("Product updated");
        }


        [Authorize(Roles = "Admin")]
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            _service.DeleteProduct(id);
            return Ok("Product deleted");
        }


    }
}
