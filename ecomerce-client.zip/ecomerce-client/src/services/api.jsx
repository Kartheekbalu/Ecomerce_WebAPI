const BASE_URL = "https://localhost:44329/api";

export const getProducts = async () => {
  const response = await fetch(`${BASE_URL}/Product/`);
  return response.json();
};

export const getProductById = async (id) => {
  const response = await fetch(`${BASE_URL}/Product/${id}`);
  return response.json();
};


export const getCats = async () => {
  const response = await fetch(`${BASE_URL}/Category/` ,{
    method: "GET",
    headers: {
    Authorization: `Bearer ${localStorage.getItem("token")}`
  }
  });
  return response.json();
};

export const loginUser = async (data) => {
  const response = await fetch(`${BASE_URL}/User/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  return response.json();
};

export const signupUser = async (data) => {
  const response = await fetch(`${BASE_URL}/User/signup`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  return response.json();
};


// Adding token in every request
// fetch("https://localhost:5001/api/expenses", {
//   headers: {
//     Authorization: `Bearer ${localStorage.getItem("token")}`
//   }
// });

const getAuthHeader = () => ({
  "Content-Type": "application/json",
  Authorization: `Bearer ${localStorage.getItem("token")}`,
});

export const addToCart = async (data) => {
  return fetch(`${BASE_URL}/cart`, {
    method: "POST",
    headers: getAuthHeader(),
    body: JSON.stringify(data),
  });
};

export const getCart = async () => {
  const res = await fetch(`${BASE_URL}/cart`, {
    headers: getAuthHeader(),
  });
  return res.json();
};

export const updateCartQty = async (productId, quantity) => {
  return fetch(`${BASE_URL}/cart/${productId}`, {
    method: "PUT",
    headers: getAuthHeader(),
    body: JSON.stringify({ quantity }),
  });
};

export const deleteCartItem = async (productId) => {
  return fetch(`${BASE_URL}/cart/${productId}`, {
    method: "DELETE",
    headers: getAuthHeader(),
  });
};


// Place Order
export const placeOrder = async () => {
  const res = await fetch("https://localhost:44329/api/order", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${localStorage.getItem("token")}`,
    },
  });

  if (!res.ok) throw new Error("Order failed");
};

// Get Orders
export const getOrders = async () => {
  const res = await fetch("https://localhost:44329/api/order", {
    headers: {
      Authorization: `Bearer ${localStorage.getItem("token")}`,
    },
  });
  return res.json();
};