import { useEffect, useState } from "react";
import { getProducts, addToCart, getCart } from "../services/api";
import { useNavigate } from "react-router-dom";

function Home() {
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState("");
  const [cartProductIds, setCartProductIds] = useState([]);

  const navigate = useNavigate();
  const token = localStorage.getItem("token");

  // Load products
  useEffect(() => {
    getProducts().then(data => setProducts(data));
  }, []);

  // Load cart (only if logged in)
  useEffect(() => {
    if (!token) return;

    getCart().then(data => {
      const ids = data.map(item => item.productId);
      setCartProductIds(ids);
    });
  }, [token]);

  const filteredProducts = products.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase())
  );

  const handleAddToCart = (e, productId) => {
    e.stopPropagation();

    if (!token) {
      alert("Please login first");
      return;
    }

    const qty = prompt("Enter quantity:");
    if (!qty || qty <= 0) return;

    addToCart({
      productId: productId,
      quantity: parseInt(qty),
    }).then(() => {
      alert("Added to cart");
      setCartProductIds(prev => [...prev, productId]);
    });
  };

  return (
    <>
      {/* HERO SECTION */}
      <div className="bg-dark text-white text-center p-5">
        <h1>Welcome to E-Commerce</h1>
        <p className="mt-2">Find the best products at the best prices</p>
      </div>

      {/* PRODUCT SECTION */}
      <div className="container mt-5">
        <h2 className="mb-4 text-center">Products</h2>

        {/* SEARCH BAR */}
        <div className="row mb-4">
          <div className="col-md-6 mx-auto">
            <input
              type="text"
              className="form-control"
              placeholder="Search products..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>

        <div className="row">
          {filteredProducts.map(p => (
            <div className="col-md-3 mb-4" key={p.id}>
              <div
                className="card product-card h-100"
                onClick={() => navigate(`/product/${p.id}`)}
              >
                <img
                  src={p.imageUrl || "https://via.placeholder.com/300"}
                  className="card-img-top"
                  alt={p.name}
                />

                <div className="card-body text-center">
                  <h5 className="card-title">{p.name}</h5>
                  <p className="text-success fw-bold">₹ {p.price}</p>
                </div>

                <div className="text-center mb-3">
                  {cartProductIds.includes(p.id) ? (
                    <button className="btn btn-success btn-sm" disabled>
                      Added ✓
                    </button>
                  ) : (
                    <button
                      className="btn btn-primary btn-sm"
                      onClick={(e) => handleAddToCart(e, p.id)}
                    >
                      Add to Cart
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <p className="text-center mt-4">No products found</p>
        )}
      </div>
    </>
  );
}

export default Home;
