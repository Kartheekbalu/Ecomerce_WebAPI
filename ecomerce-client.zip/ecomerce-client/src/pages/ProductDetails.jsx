import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { getProductById } from "../services/api";

function ProductDetails() {
  const { id } = useParams();
  const [product, setProduct] = useState(null);

  useEffect(() => {
    getProductById(id).then(data => setProduct(data));
  }, [id]);

  if (!product) {
    return <div className="container mt-4">Loading...</div>;
  }

  return (
    <div className="container mt-5">
      <div className="row">
        {/* Image */}
        <div className="col-md-5">
          <img
            src={product.imageUrl || "https://via.placeholder.com/400"}
            className="img-fluid"
            alt={product.name}
          />
        </div>

        {/* Details */}
        <div className="col-md-7">
          <h2>{product.name}</h2>
          <h4 className="text-success mt-3">₹ {product.price}</h4>

          <p className="mt-4">{product.description}</p>

          <button className="btn btn-primary mt-3">
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
}

export default ProductDetails;
    