import { useEffect, useState } from "react";
import { getCats } from "../services/api";

function Cats() {
  const [cats, setCats] = useState([]);

  useEffect(() => {
    getCats()
      .then((data) => setCats(data))
      .catch((err) => console.log(err));
  }, []);

  return (
    <div className="container">
      <h2>Categories</h2>

      <div className="product-grid">
        {cats.map((c) => (
          <div className="product-card" key={c.id}>
            <h4>{c.name}</h4>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Cats;
