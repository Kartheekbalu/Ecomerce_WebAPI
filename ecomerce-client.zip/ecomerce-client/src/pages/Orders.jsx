import { useEffect, useState } from "react";
import { getOrders } from "../services/api";

function Orders() {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    getOrders().then(data => setOrders(data));
  }, []);

  return (
    <div className="container mt-5">
      <h2 className="mb-4">My Orders</h2>

      {orders.length === 0 && (
        <p className="text-center">No orders yet</p>
      )}

      {orders.map(order => (
        <div className="card mb-3" key={order.id}>
          <div className="card-body">
            <h5 className="card-title">{order.productName}</h5>
            <p>Quantity: {order.quantity}</p>
            <p>Price: ₹ {order.price}</p>
            <span className="badge bg-success">
              {order.status}
            </span>
          </div>
        </div>
      ))}
    </div>
  );
}

export default Orders;
