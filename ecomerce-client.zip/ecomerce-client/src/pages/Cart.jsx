import { useEffect, useState } from "react";
import {
  getCart,
  updateCartQty,
  deleteCartItem,
  placeOrder,
} from "../services/api";
import { useNavigate } from "react-router-dom";

function Cart() {
  const [cart, setCart] = useState([]);
  const navigate = useNavigate();

  const loadCart = () => {
    getCart().then(data => setCart(data));
  };

  useEffect(() => {
    loadCart();
  }, []);

  const grandTotal = cart.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  const handlePlaceOrder = () => {
    placeOrder()
      .then(() => {
        alert("Order placed successfully");
        navigate("/orders");
      })
      .catch(() => alert("Order failed"));
  };

  return (
    <div className="container mt-5">
      <h2>My Cart</h2>

      {cart.length === 0 && <p>Your cart is empty</p>}

      {cart.length > 0 && (
        <>
          <table className="table mt-3">
            <thead>
              <tr>
                <th>Product</th>
                <th>Price</th>
                <th>Qty</th>
                <th>Total</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {cart.map(c => (
                <tr key={c.productId}>
                  <td>{c.productName}</td>
                  <td>₹ {c.price}</td>
                  <td>
                    <input
                      type="number"
                      value={c.quantity}
                      min="1"
                      style={{ width: "70px" }}
                      onChange={(e) =>
                        updateCartQty(c.productId, e.target.value)
                          .then(loadCart)
                      }
                    />
                  </td>
                  <td>₹ {c.price * c.quantity}</td>
                  <td>
                    <button
                      className="btn btn-danger btn-sm"
                      onClick={() =>
                        deleteCartItem(c.productId).then(loadCart)
                      }
                    >
                      Remove
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* ORDER SUMMARY */}
          <div className="d-flex justify-content-between align-items-center mt-4">
            <h5>Grand Total: ₹ {grandTotal}</h5>
            <button
              className="btn btn-success"
              onClick={handlePlaceOrder}
            >
              Place Order
            </button>
          </div>
        </>
      )}
    </div>
  );
}

export default Cart;
